print('find the flag!')
